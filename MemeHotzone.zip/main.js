function showNextImage() {
  var images = document.querySelectorAll('.memecontainer img');
  var currentImageIndex = 0;

  // Find the current visible image
  for (var i = 0; i < images.length; i++) {
    if (images[i].style.display !== 'none') {
      currentImageIndex = i;
      break;
    }
  }

  // Hide the current image and show the next one
  images[currentImageIndex].style.display = 'none';
  if (currentImageIndex < images.length - 1) {
    images[currentImageIndex + 1].style.display = 'block';
  } else {
    images[0].style.display = 'block';
  }
}
